# worklog.nvim

Small Markdown worklog/TODO helper for Neovim.

It keeps tasks in three sections:

```md
### TODO
### IN PROGRESS
### ARCHIVE
```

Inside a daily section (`# dd-mm-yyyy`) it works only inside that day. Outside a daily section it falls back to global sections:

```md
## TODO
## IN PROGRESS
## ARCHIVE
```

## Install with vim-plug

```vim
Plug '~/.config/nvim/plugins/worklog.nvim'
Plug 'bngarren/checkmate.nvim'
```

Then:

```lua
require('worklog').setup()
```

## Suggested local path

```sh
mkdir -p ~/.config/nvim/plugins
cp -R worklog.nvim ~/.config/nvim/plugins/worklog.nvim
```

## Commands

```vim
:TodoToday
:TodoCreate
:TodoCreateInProgress
:TodoMoveInProgress
:TodoNormalizeSections
```

## Default mappings

| Key | Action |
| --- | --- |
| `<leader>jD` | create/jump to today's section |
| `<leader>js` | same as above |
| `<leader>jn` | create TODO |
| `<leader>jt` / `<leader>jj` | cycle TODO -> IN PROGRESS -> ARCHIVE -> TODO |
| `<leader>jT` / `<leader>jJ` | cycle backwards |
| `<leader>jd` | mark done and move to ARCHIVE |
| `<leader>ju` | mark unchecked and move to TODO |
| `<leader>ji` | mark in progress and move to IN PROGRESS |
| `<leader>jr` | remove checkbox marker |
| `<leader>ja` | normalize current day/global sections |
| `<leader>ka` | add/update @tag(value) |
| `<leader>kt` | toggle @tag(value) |
| `<leader>kr` | remove tag under cursor or by name |
| `<leader>kR` | remove user tags, keep @start/@end/@lasted |
| `<leader>kv` | edit value under cursor |
| `<leader>k]` | next metadata tag |
| `<leader>k[` | previous metadata tag |

## Configuration

```lua
require('worklog').setup({
  notify = true,
  checkmate = {
    enabled = true,
  },
  keys = {
    cycle_next = '<leader>jt',
    cycle_next_alt = '<leader>jj',
    metadata_toggle = '<leader>kt',
  },
})
```

Set any key to `false` to disable it.

```lua
require('worklog').setup({
  keys = {
    cycle_next_alt = false,
  },
})
```
