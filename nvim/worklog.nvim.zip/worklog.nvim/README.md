# worklog.nvim

Local Neovim plugin for scoped Markdown worklogs with Checkmate-style TODO states.

## Features

- Daily sections as `# dd-mm-yyyy` with `---------` separator.
- Per-day task scope: `### TODO`, `### IN PROGRESS`, `### ARCHIVE`.
- Task state movement with timestamps at end of task:
  - `@start(dd-mm-yyyy HH:MM)` when task enters IN PROGRESS.
  - `@end(dd-mm-yyyy HH:MM)` and `@lasted(...)` when task enters ARCHIVE.
- Simple metadata/tag management without Telescope picker surprises.
- Optional Checkmate setup included.

## Install with vim-plug

Clone or copy this directory to:

```bash
mkdir -p ~/.config/nvim/plugins
cp -r worklog.nvim ~/.config/nvim/plugins/worklog.nvim
```

Then in `init.lua` keep your normal plugin block and add:

```lua
Plug '~/.config/nvim/plugins/worklog.nvim'
```

After `call plug#end()`, add:

```lua
require("worklog").setup()
```

Keep `Plug 'bngarren/checkmate.nvim'` installed if you want the Checkmate icons/highlights.

## Keymaps

Worklog/TODO:

```txt
<leader>jn  new TODO in current day/global TODO
<leader>jt  cycle TODO -> IN PROGRESS -> ARCHIVE -> TODO
<leader>jT  cycle backwards
<leader>jd  mark done/archive, add @end and @lasted
<leader>ji  mark in progress, add @start
<leader>ju  move back to TODO, remove time metadata
<leader>jr  remove checkbox marker
<leader>ja  normalize current day/global sections
<leader>js  create/jump to today's worklog section
<leader>jD  create/jump to today's worklog section
```

Metadata/tags:

```txt
<leader>ka  add/update @tag(value)
<leader>kv  edit value under cursor
<leader>kr  remove tag under cursor or by name
<leader>kR  remove user tags, keep @start/@end/@lasted
<leader>kt  toggle tag
<leader>k]  next metadata tag
<leader>k[  previous metadata tag
```

## Minimal init.lua usage

```lua
vim.g.mapleader = " "

call plug#begin()
Plug 'bngarren/checkmate.nvim'
Plug '~/.config/nvim/plugins/worklog.nvim'
call plug#end()

require("worklog").setup()
```
